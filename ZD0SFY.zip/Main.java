import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static int hossz;
    static int szelesseg;
    static int oszlopok_szama;
    static int raklapok_szama;
    static ArrayList<Raklap> raklapok = new ArrayList<>();
    static Raktar raktar;

    public static void main(String [ ] args) throws IOException {


        Scanner sc = new Scanner(System.in);

        // Raktar hossz es szelesseg beolvasas
        //System.out.println("Raktar hossza es szelessege: ");

        String[] adatok = sc.nextLine().split("\t");
        hossz = Integer.parseInt(adatok[0]);
        szelesseg = Integer.parseInt(adatok[1]);

        raktar = new Raktar(hossz,szelesseg);

        // Oszlopok szama
        //System.out.println("Oszlopok szama: ");
        String adat = sc.nextLine();
        oszlopok_szama = Integer.parseInt(adat);

        // Raklapok szama
        //System.out.println("Raklapok szama: ");
        adat = sc.nextLine();
        raklapok_szama = Integer.parseInt(adat);

        // Oszlopok beolvasasa
        //System.out.println("Oszlopok beolvasasa: ");
        for (int i = 0; i<oszlopok_szama; i++){
            adatok = sc.nextLine().split("\t");
            int h = Integer.parseInt(adatok[0]);
            int sz = Integer.parseInt(adatok[1]);
            raktar.addOszlop(new Oszlop(h,sz));
        }

        //Raklapok beolvasasa
        //System.out.println("Raklapok beolvasasa: ");
        for (int i = 0; i<raklapok_szama; i++){
            adatok = sc.nextLine().split("\t");
            int h = Integer.parseInt(adatok[0]);
            int sz = Integer.parseInt(adatok[1]);
            Raklap r = new Raklap(h,sz);
            r.forgatas();
            raklapok.add(r);
        }

        //test1();
        //test2();
        initHanyszorFerBele();
        // Raktar megjelenitese
       // raktar.megjelenit();

        while (raklapok_szama!=0){
            //System.out.println();
            Raklap r = raktar.legkevesebbElhelyezes(raklapok);
            boolean megvan = raktar.hovaHelyezze(r);
            if(megvan)raktar.addRaklap(r);
            else {

            }
            //System.out.println();
            //raktar.megjelenit();
            initHanyszorFerBele();
        }
        raktar.megjelenit();
    }
    public static String[] beolvas(Scanner sc){
        String bemenet = sc.nextLine();
        return bemenet.split("\t");
    }
    public static void test1(){
        hossz = 5;
        szelesseg = 7;
        raktar = new Raktar(hossz,szelesseg);
        oszlopok_szama = 2;
        raklapok_szama = 7;
        raktar.addOszlop(new Oszlop(2,2));
        raktar.addOszlop(new Oszlop(3,4));
        raklapok.add(new Raklap(4,2));
        raklapok.add(new Raklap(3,2));
        raklapok.add(new Raklap(1,2));
        raklapok.add(new Raklap(2,5));
        raklapok.add(new Raklap(2,2));
        raklapok.add(new Raklap(2,1));
        raklapok.add(new Raklap(3,1));
    }
    public static void initHanyszorFerBele(){
        for(int i = 0; i<raklapok_szama;i++){
            raklapok.get(i).elfer = raktar.hanyszorFerBele(raklapok.get(i));
            //System.out.println(raklapok.get(i).elfer + " ez tartozik az " + i + ". elemhez.");
        }
    }
    /*public static void test2() throws FileNotFoundException {
        File object = new File("mi.txt");
        Scanner sc = new Scanner(object);
        String adat;
        String[] adatok;
        adatok = sc.nextLine().split("\t");
        System.out.println(adatok[0]);
        System.out.println(adatok[1]);
        hossz = Integer.parseInt(adatok[0]);
        szelesseg = Integer.parseInt(adatok[1]);
        raktar = new Raktar(hossz,szelesseg);
        adat = sc.nextLine();
        oszlopok_szama = Integer.parseInt(adat);
        adat = sc.nextLine();
        raklapok_szama = Integer.parseInt(adat);
        for(int i = 0; i<oszlopok_szama;i++){
            adatok = sc.nextLine().split("\t");
            int h = Integer.parseInt(adatok[0]);
            int sz = Integer.parseInt(adatok[1]);
            raktar.addOszlop(new Oszlop(h,sz));
        }
        for(int i = 0; i<raklapok_szama;i++){
            adatok = sc.nextLine().split("\t");
            int h = Integer.parseInt(adatok[0]);
            int sz = Integer.parseInt(adatok[1]);
            Raklap r = new Raklap(h,sz);
            r.forgatas();
            raklapok.add(r);
        }
    }*/
}
