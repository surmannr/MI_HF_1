public class Oszlop {

    public int h1;
    public int sz1;

    public int h2;
    public int sz2;

    Oszlop(int h, int sz){
        h2 = h;
        sz2 = sz;

        h1 = h2-1;
        sz1 = sz2-1;
    }
}
